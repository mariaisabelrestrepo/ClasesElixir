# CHANGELOG

## 1.0.1

  * Add `embed_templates/2` for convenience

## 1.0.0

  * Initial release
